# My Test App

This is a test application for demonstrating the Binary Manager.

## Structure

- `src/` - Source code
- `lib/` - Utility libraries

## Usage

```bash
python3 src/main.py
```

## Version

1.0.0
