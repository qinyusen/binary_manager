# Simple Calculator

A simple Python calculator application.

## Features

- Addition
- Subtraction
- Multiplication
- Division

## Usage

```bash
python3 calculator.py
```

## Version

1.0.0
