"""
Utility functions for the application
"""


def calculate_sum(a: int, b: int) -> int:
    return a + b


def multiply(a: int, b: int) -> int:
    return a * b
